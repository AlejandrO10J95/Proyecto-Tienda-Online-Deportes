export interface CarritoItem {
  producto_id: number;
  cantidad: number;
}