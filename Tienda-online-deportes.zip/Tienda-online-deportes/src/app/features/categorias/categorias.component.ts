import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CategoriasService } from '../../core/services/categorias.service';
import { NgFor, NgClass } from '@angular/common';

@Component({
  selector: 'app-categorias',
  standalone: true,
  imports: [NgFor, NgClass],
  template: `
    <ul>
      <li *ngFor="let categoria of categorias()"
          [ngClass]="{ 'seleccionada': categoria.id === seleccionada() }"
          (click)="seleccionarCategoria(categoria)">
        {{ categoria.nombre }}
      </li>
    </ul>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CategoriasComponent {
  private categoriasService = inject(CategoriasService);
  categorias = signal<any[]>([]);
  seleccionada = signal<number | null>(null);

  constructor() {
    this.categoriasService.getCategorias().subscribe(data => this.categorias.set(data));
  }

  seleccionarCategoria(categoria: any) {
    this.seleccionada.set(categoria.id);
  }
}