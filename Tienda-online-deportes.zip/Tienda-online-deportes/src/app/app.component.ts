import { Component, ChangeDetectionStrategy, signal, computed } from '@angular/core';
import { CategoriasComponent } from './features/categorias/categorias.component';
import { ProductosComponent } from './features/productos/productos.component';
import { CarritoComponent } from './features/carrito/carrito.component';
import { CarritoService } from './core/services/carrito.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CategoriasComponent, ProductosComponent, CarritoComponent],
  template: `
    <header>
      <h1>Tienda Deportiva</h1>
      <a class="carrito-icono" href="#" (click)="toggleCarrito()">
        🛒 ({{ cantidadProductos() }})
      </a>
    </header>
    <main style="display: flex;">
      <aside style="width: 20%;">
        <app-categorias></app-categorias>
      </aside>
      <section style="width: 80%;">
        <app-productos></app-productos>
      </section>
    </main>
    <app-carrito *ngIf="mostrarCarrito()"></app-carrito>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent {
  private mostrarCarrito = signal(false);
  private carritoService = new CarritoService();

  cantidadProductos = computed(() => this.carritoService.cantidadTotal());

  toggleCarrito() {
    this.mostrarCarrito.update(v => !v);
  }

  mostrarCarrito() {
    return this.mostrarCarrito();
  }
}